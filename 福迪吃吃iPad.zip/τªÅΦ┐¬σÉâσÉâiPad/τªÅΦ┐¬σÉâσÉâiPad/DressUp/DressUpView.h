//
//  DressUpView.h
//  福迪吃吃iPad
//
//  Created by 张思扬 on 2023/6/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DressUpView : UIView
- (void)Init;
@end

NS_ASSUME_NONNULL_END
