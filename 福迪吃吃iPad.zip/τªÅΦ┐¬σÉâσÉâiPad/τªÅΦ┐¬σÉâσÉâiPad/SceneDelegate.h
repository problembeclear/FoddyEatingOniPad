//
//  SceneDelegate.h
//  福迪吃吃iPad
//
//  Created by 张思扬 on 2023/6/19.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

