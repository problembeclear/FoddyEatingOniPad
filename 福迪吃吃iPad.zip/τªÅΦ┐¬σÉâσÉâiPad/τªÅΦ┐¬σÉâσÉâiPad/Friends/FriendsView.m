//
//  FriendsView.m
//  福迪吃吃iPad
//
//  Created by 张思扬 on 2023/6/22.
//

#import "FriendsView.h"

@implementation FriendsView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
