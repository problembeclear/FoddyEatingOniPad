//
//  AppDelegate.h
//  福迪吃吃iPad
//
//  Created by 张思扬 on 2023/6/19.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

